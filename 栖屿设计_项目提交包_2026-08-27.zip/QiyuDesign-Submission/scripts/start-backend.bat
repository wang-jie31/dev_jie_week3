@echo off
chcp 65001 >nul
REM ============================================
REM  Qiyu Design · 通用启动脚本（双击可用）
REM  自动定位到本包内 01-code，不依赖本机绝对路径
REM  前置要求：已按 05-deploy 指南安装环境并 npm install
REM ============================================
title Qiyu 后端 8000
cd /d "%~dp0..\01-code\qiyu-design\api"
set PY=python
if exist ".venv\Scripts\python.exe" set PY=.venv\Scripts\python.exe
echo 启动后端（Python: %PY%）...
start "Qiyu 后端 8000" cmd /k "%PY% -m uvicorn app.main:app --host 0.0.0.0 --port 8000"

set /a tries=0
:wait_api
timeout /t 2 /nobreak >nul
set /a tries+=1
netstat -ano | findstr ":8000" | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
  if %tries% gtr 45 ( echo 后端启动超时，请手动打开 http://localhost:8000/docs ) else ( goto wait_api )
) else (
  start "" "http://localhost:8000/docs"
  echo 已打开接口文档 http://localhost:8000/docs
)
pause
