@echo off
chcp 65001 >nul
REM ============================================
REM  Qiyu Design · 通用启动脚本（双击可用）
REM  自动定位到本包内 01-code，不依赖本机绝对路径
REM  前置要求：已按 05-deploy 指南安装环境并 npm install
REM ============================================
title Qiyu Design · 一键启动
echo [1/3] 后端 FastAPI (8000) ...
cd /d "%~dp0..\01-code\qiyu-design\api"
set PY=python
if exist ".venv\Scripts\python.exe" set PY=.venv\Scripts\python.exe
start "Qiyu 后端 8000" cmd /k "%PY% -m uvicorn app.main:app --host 0.0.0.0 --port 8000"

echo [2/3] 后台 Vite (5173) ...
cd /d "%~dp0..\01-code\qiyu-design\apps\backend"
start "Qiyu 后台 5173" cmd /k "npm run dev"

echo [3/3] 前台 Next.js (3000) ...
cd /d "%~dp0..\01-code\qiyu-design\apps\frontend"
start "Qiyu 前台 3000" cmd /k "npm run dev"

echo 服务启动中，就绪后自动打开浏览器（后台/后端约 3~5 秒，前台首次约 15~30 秒）...

set /a tries=0
:wait_admin
timeout /t 2 /nobreak >nul
set /a tries+=1
netstat -ano | findstr ":5173" | findstr "LISTENING" >nul 2>&1
if errorlevel 1 ( if %tries% gtr 45 ( echo 后台超时，手动开 http://localhost:5173 ) else ( goto wait_admin ) ) else ( start "" "http://localhost:5173" & echo 已打开后台 )

set /a tries=0
:wait_api
timeout /t 2 /nobreak >nul
set /a tries+=1
netstat -ano | findstr ":8000" | findstr "LISTENING" >nul 2>&1
if errorlevel 1 ( if %tries% gtr 45 ( echo 后端超时，手动开 http://localhost:8000/docs ) else ( goto wait_api ) ) else ( start "" "http://localhost:8000/docs" & echo 已打开接口文档 )

set /a tries=0
:wait_web
timeout /t 2 /nobreak >nul
set /a tries+=1
netstat -ano | findstr ":3000" | findstr "LISTENING" >nul 2>&1
if errorlevel 1 ( if %tries% gtr 60 ( echo 前台超时，手动开 http://localhost:3000 ) else ( goto wait_web ) ) else ( start "" "http://localhost:3000" & echo 已打开前台 )

echo 全部就绪！各服务窗口请勿关闭。
pause
