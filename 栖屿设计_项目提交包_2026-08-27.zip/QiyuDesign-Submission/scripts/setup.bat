@echo off
chcp 65001 >nul
REM ============================================
REM  Qiyu Design · 一键初始化（首次运行，约 5~15 分钟）
REM  完成 5 件事：配置检查 → 建库 → 后端依赖+建表+演示数据
REM              → 前台后台依赖安装 → 完成
REM  之后每次启动只需双击 start-all.bat
REM ============================================
title Qiyu Design · 一键初始化（首次运行）
cd /d "%~dp0.."

echo ============================================
echo  第 1 步 / 5：检查配置文件 .env
echo ============================================
if not exist ".env" (
  copy /y ".env.example" ".env" >nul
  echo.
  echo  [首次运行] 已自动生成 .env 配置文件。
  echo  请用记事本打开解压根目录的 .env，把这一行：
  echo    DATABASE_URL=postgresql+psycopg://postgres:CHANGE_ME@localhost:5432/qiyu
  echo  改成你的数据库密码（把 CHANGE_ME 换成安装 PostgreSQL 时设置的密码），
  echo  保存后重新双击本脚本继续！
  echo.
  pause
  exit /b 1
)
echo  [OK] .env 已存在

echo ============================================
echo  第 2 步 / 5：准备数据库 qiyu
echo ============================================
where psql >nul 2>&1
if errorlevel 1 (
  echo  [提示] 未在系统 PATH 中找到 psql 命令。
  echo  两种处理方式（任选其一）：
  echo    A. 用 pgAdmin 图形界面手动创建数据库 qiyu，然后重新双击本脚本
  echo    B. 把 PostgreSQL 的 bin 目录加入 PATH 后重开本窗口再运行
  echo       （通常为 C:\Program Files\PostgreSQL\16\bin）
  pause
  exit /b 1
)
set /p DBPWD=请输入 PostgreSQL 的 postgres 用户密码：
set PGPASSWORD=%DBPWD%
psql -U postgres -h localhost -p 5432 -tc "SELECT 1 FROM pg_database WHERE datname='qiyu'" | findstr "1" >nul 2>&1
if errorlevel 1 (
  psql -U postgres -h localhost -p 5432 -c "CREATE DATABASE qiyu;" >nul 2>&1
  if errorlevel 1 ( echo  [错误] 建库失败：请检查密码是否正确、PostgreSQL 服务是否已启动 & pause & exit /b 1 )
  echo  [OK] 已创建数据库 qiyu
) else (
  echo  [OK] 数据库 qiyu 已存在
)

echo ============================================
echo  第 3 步 / 5：后端依赖 + 建表 + 演示数据
echo ============================================
cd /d "%~dp0..\01-code\qiyu-design\api"
if not exist ".venv" (
  echo  创建 Python 虚拟环境...
  python -m venv .venv
  if errorlevel 1 ( echo  [错误] 创建 venv 失败：请确认已安装 Python 3.12+ 并勾选 Add to PATH & pause & exit /b 1 )
)
echo  安装后端依赖（首次约 1~3 分钟）...
.venv\Scripts\python.exe -m pip install -r requirements.txt -q
if errorlevel 1 ( echo  [错误] 依赖安装失败：请确认网络可访问 pypi.org & pause & exit /b 1 )
echo  执行数据库迁移（建 20 张表）...
.venv\Scripts\python.exe -m alembic upgrade head
if errorlevel 1 ( echo  [错误] 建表失败，请检查 .env 的 DATABASE_URL & pause & exit /b 1 )
echo  导入演示数据...
psql -U postgres -h localhost -p 5432 -d qiyu -f "%~dp0..\02-database\seed_demo.sql" >nul 2>&1
if errorlevel 1 ( echo  [警告] 演示数据导入失败，可稍后手动执行（见部署指南） ) else ( echo  [OK] 演示数据已导入 )
echo  [OK] 后端环境就绪

echo ============================================
echo  第 4 步 / 5：安装前台 + 后台依赖（首次约 5~10 分钟）
echo ============================================
cd /d "%~dp0..\01-code\qiyu-design"
call npm install
if errorlevel 1 ( echo  [错误] npm install 失败：请确认 Node.js 18+ 已安装、网络可用 & pause & exit /b 1 )
echo  [OK] 前台/后台依赖就绪

echo ============================================
echo  第 5 步 / 5：初始化完成！
echo ============================================
echo.
echo  以后启动网站：双击「scripts\start-all.bat」
echo  （依次启动 后端:8000 / 后台:5173 / 前台:3000 并自动打开浏览器）
echo.
pause
