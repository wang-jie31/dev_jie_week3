@echo off
chcp 65001 >nul
REM ============================================
REM  Qiyu Design · 通用启动脚本（双击可用）
REM  自动定位到本包内 01-code，不依赖本机绝对路径
REM  前置要求：已按 05-deploy 指南安装环境并 npm install
REM ============================================
title Qiyu 前台 3000
cd /d "%~dp0..\01-code\qiyu-design\apps\frontend"
if not exist node_modules (
  echo [错误] 未安装依赖，请先按 05-deploy 指南执行 npm install
  pause & exit /b 1
)
echo 启动前台 Next.js（首次编译约 15~30 秒）...
start "Qiyu 前台 3000" cmd /k "npm run dev"

set /a tries=0
:wait_web
timeout /t 2 /nobreak >nul
set /a tries+=1
netstat -ano | findstr ":3000" | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
  if %tries% gtr 60 ( echo 前台启动超时，请手动打开 http://localhost:3000 ) else ( goto wait_web )
) else (
  start "" "http://localhost:3000"
  echo 已打开前台 http://localhost:3000
)
pause
