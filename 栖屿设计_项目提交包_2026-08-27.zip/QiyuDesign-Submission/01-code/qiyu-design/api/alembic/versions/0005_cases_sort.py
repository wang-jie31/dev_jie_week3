"""0005_cases_sort: 案例前台展示排序字段（2026-08-27 修复）

Revision ID: 0005_cases_sort
Revises: 0004_packages_sort
Create Date: 2026-08-27

说明：0004 只给 packages 加了 sort，Case 模型与 cases 表缺失，
导致 repository 中 Case.sort 引用报 AttributeError → /api/v1/home 500。
此处补齐 cases.sort 列。
"""

from alembic import op
import sqlalchemy as sa

revision = "0005_cases_sort"
down_revision = "0004_packages_sort"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "cases",
        sa.Column("sort", sa.Integer(), nullable=False, server_default="0"),
    )


def downgrade() -> None:
    op.drop_column("cases", "sort")