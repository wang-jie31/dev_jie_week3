"""0004_packages_sort: 套餐前台展示排序字段（2026-08-27）

Revision ID: 0004_packages_sort
Revises: 0003_pkg_area_coef_jsonb
Create Date: 2026-08-27

说明：用户需求「案例/套餐前台展示顺序可在后台设置」——
  cases 表已有 sort 列（0001_initial），packages 表补上 sort。
  前台公开列表按 sort ASC, id ASC 展示；后台列表提供上移/下移与数字输入。
"""

from alembic import op
import sqlalchemy as sa

revision = "0004_packages_sort"
down_revision = "0003_pkg_area_coef_jsonb"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "packages",
        sa.Column("sort", sa.Integer(), nullable=False, server_default="0"),
    )


def downgrade() -> None:
    op.drop_column("packages", "sort")