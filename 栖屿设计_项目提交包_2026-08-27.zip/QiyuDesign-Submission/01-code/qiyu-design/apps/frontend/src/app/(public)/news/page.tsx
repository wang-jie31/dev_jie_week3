/**
 * 新闻列表页（S-14）—— Hero → 分类 chips（企业/行业）→ 列表（左图右文）→ 分页条
 */
import type { Metadata } from "next";
import { api } from "@/lib/api";
import { NewsRow } from "@/components/Cards";
import PageHero from "@/components/PageHero"; // 页面 Hero 横幅（图+介绍+居中）
import { seoMetadata } from "@/lib/seo";
import ClientNewsList from "./client";

export const revalidate = 60;

export const metadata: Metadata = seoMetadata({
  title: "新闻资讯",
  description: "栖屿设计动态与行业观察 —— 企业新闻、行业资讯、装修干货，陪你一起把小家越住越好。",
  path: "/news",
});

export interface NewsListSearchParams {
  cat?: string;
  page?: string;
}

export default async function NewsPage({
  searchParams,
}: {
  searchParams: Promise<NewsListSearchParams>;
}) {
  const sp = await searchParams;
  const page = Number(sp.page) || 1;
  const pageSize = 10;
  const data = await api.news(
    { cat: sp.cat, page: String(page), pageSize: String(pageSize) },
    60,
  );

  return (
    <div className="mx-auto max-w-[1280px] px-6 pb-16">
      {/* 页头 Hero：全幅图 + 介绍 + 文字居中（对齐原型 .page-hero） */}
      <PageHero
        image="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1920&q=80"
        eyebrow="News"
        title="新闻资讯"
        sub="栖屿动态与行业观察，陪你一起把小家越住越好。"
      />

      <ClientNewsList data={data} page={page} pageSize={pageSize} active={{ cat: sp.cat }} />
    </div>
  );
}