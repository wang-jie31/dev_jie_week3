/**
 * 套餐列表页（S-13）—— 对齐原型 + UIUX §7.4：
 * Hero → 类型筛选 chips（全部/单空间/全屋/风格）→ 3 卡网格（双轨价格 + 最受欢迎徽章）→ 分页条
 */
import type { Metadata } from "next";
import { api } from "@/lib/api";
import { PackageCard } from "@/components/Cards";
import PageHero from "@/components/PageHero"; // 页面 Hero 横幅（图+介绍+居中）
import { seoMetadata } from "@/lib/seo";
import ClientPackageList from "./client";

export const revalidate = 30; // ISR 30s

export const metadata: Metadata = seoMetadata({
  title: "服务套餐",
  description: "栖屿设计套餐服务 —— 单空间定制 / 全屋整装 / 风格定制，双轨价格透明，按房型与风格打包，预算一眼看清。",
  path: "/packages",
});

export interface PackageListSearchParams {
  type?: string;
  page?: string;
}

export default async function PackagesPage({
  searchParams,
}: {
  searchParams: Promise<PackageListSearchParams>;
}) {
  const sp = await searchParams;
  const page = Number(sp.page) || 1;
  const pageSize = 9; // 套餐 3 列网格
  const data = await api.packages(
    { type: sp.type, page: String(page), pageSize: String(pageSize) },
    30,
  );

  return (
    <div className="mx-auto max-w-[1280px] px-6 pb-16">
      {/* 页头 Hero：全幅图 + 介绍 + 文字居中（对齐原型 .page-hero） */}
      <PageHero
        image="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1920&q=80"
        eyebrow="Service Packages"
        title="服务套餐"
        sub="弱化平方米计价，按房间 / 户型 / 风格打包，降低决策门槛，预算一眼看清。"
      />

      <ClientPackageList data={data} page={page} pageSize={pageSize} active={{ type: sp.type }} />
    </div>
  );
}