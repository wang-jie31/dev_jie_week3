/**
 * 招聘页（S-14）—— Hero → 分类 chips（社会/校园）→ 职位卡片列表 → 投递提示
 */
import { api } from "@/lib/api";
import { seoMetadata } from "@/lib/seo";
import PageHero from "@/components/PageHero"; // 页面 Hero 横幅（图+介绍+居中）
import ClientCareers from "./client";

export const revalidate = 60;

export const metadata = seoMetadata({
  title: "加入我们 · 招聘",
  description: "栖屿设计招聘 —— 社会招聘与校园招聘，室内设计师 / 深化 / 商务等岗位持续开放。",
  path: "/careers",
});

export interface CareersSearchParams {
  cat?: string;
}

export default async function CareersPage({
  searchParams,
}: {
  searchParams: Promise<CareersSearchParams>;
}) {
  const sp = await searchParams;
  const items = await api.careers({ cat: sp.cat }, 60);

  return (
    <div className="mx-auto max-w-[1280px] px-6 pb-16">
      {/* 页头 Hero：全幅图 + 介绍 + 文字居中（对齐原型 .page-hero） */}
      <PageHero
        image="https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=1920&q=80"
        eyebrow="Careers"
        title="招聘入口"
        sub="和一群相信「独居也可以很温暖」的人，一起把好设计带给更多人。"
      />

      <ClientCareers items={items} active={{ cat: sp.cat }} />
    </div>
  );
}