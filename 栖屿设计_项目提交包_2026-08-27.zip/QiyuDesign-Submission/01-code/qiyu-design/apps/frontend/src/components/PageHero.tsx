/**
 * PageHero —— 前台页面顶部 Hero 横幅（2026-08-27 功能补全）
 *
 * 对齐原型 static/prototype/index-v7.html 的 .page-hero 设计：
 * - 全幅大图（Unsplash w=1920 横幅格式）+ 渐变暗色遮罩
 * - 内容垂直水平居中：eyebrow 金色小标（英文）→ h1 页面名 → sub 一句话介绍
 * - 每个导航页都展示「这是什么页面、介绍什么」（用户需求）
 *
 * 用法：
 * ```tsx
 * <PageHero
 *   image="https://images.unsplash.com/photo-xxx?auto=format&fit=crop&w=1920&q=80"
 *   eyebrow="Portfolio"
 *   title="案例展示"
 *   sub="为独居青年打造的一居、开间、小两居。"
 * />
 * ```
 */
interface Props {
  image: string; // 横幅大图（1920 宽）
  eyebrow: string; // 英文小标（金色）
  title: string; // 页面名
  sub: string; // 一句话介绍
}

export default function PageHero({ image, eyebrow, title, sub }: Props) {
  return (
    <section className="relative mt-6 flex min-h-[320px] max-h-[420px] items-center justify-center overflow-hidden rounded-3xl">
      {/* 全幅大图 */}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={image}
        alt={title}
        className="absolute inset-0 h-full w-full object-cover"
      />
      {/* 渐变遮罩（对齐原型 overlay） */}
      <div className="absolute inset-0 bg-gradient-to-b from-[rgba(39,40,44,0.55)] to-[rgba(39,40,44,0.75)]" />
      {/* 居中内容 */}
      <div className="relative z-10 px-6 text-center">
        <p className="font-en text-[13px] uppercase tracking-[0.18em] text-yolk">
          {eyebrow}
        </p>
        <h1 className="mt-3 font-serif text-[2.5rem] font-extrabold leading-tight text-cream">
          {title}
        </h1>
        <p className="mx-auto mt-3 max-w-[600px] text-[14px] leading-[1.9] text-cream/85">
          {sub}
        </p>
      </div>
    </section>
  );
}
